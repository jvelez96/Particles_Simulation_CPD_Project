gcc simpar.c grid.c physics.c -lm -o simpar
