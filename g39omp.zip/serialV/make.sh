gcc simpar.c grid.c physics.c LinkedList.c -lm -o simpar
